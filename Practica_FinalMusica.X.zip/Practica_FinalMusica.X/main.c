#include "mcc.h"
#include "stdio.h"
#include "stdlib.h"
#include <xlcd.h>

void c4_do(){
    //TMR0_StartTimer();
    while(counter_vel <= (6-velocidad)){
        PORTCbits.RC1 = 1;
        __delay_us(478);
        PORTCbits.RC1 = 0;
        __delay_us(478);
    }
    TMR1Flag = 0;
    //TMR0_StopTimer();
    counter_vel = 0;
}
void d4_re(){
    //TMR0_StartTimer();
    while(counter_vel <= (6-velocidad)){
        PORTCbits.RC1 = 1;
        __delay_us(426);
        PORTCbits.RC1 = 0;
        __delay_us(426);
    }
    TMR1Flag = 0;
    //TMR0_StopTimer();
    counter_vel = 0;
}
void e4_mi(){
    //TMR0_StartTimer();
    while(counter_vel <= (6-velocidad)){
        PORTCbits.RC1 = 1;
        __delay_us(380);
        PORTCbits.RC1 = 0;
        __delay_us(380);
    }
    TMR1Flag = 0;
    //TMR0_StopTimer();
    counter_vel = 0;
}
void f4_fa(){
    //TMR0_StartTimer();
    while(counter_vel <= (6-velocidad)){
        PORTCbits.RC1 = 1;
        __delay_us(358);
        PORTCbits.RC1 = 0;
        __delay_us(358);
    }
    TMR1Flag = 0;
    //TMR0_StopTimer();
    counter_vel = 0;
}
void g4_sol(){
    //TMR0_StartTimer();
    while(counter_vel <= (6-velocidad)){
        PORTCbits.RC1 = 1;
        __delay_us(312);
        PORTCbits.RC1 = 0;
        __delay_us(312);
    }
    TMR1Flag = 0;
    //TMR0_StopTimer();
    counter_vel = 0;
}
void a4_la(){
    //TMR0_StartTimer();
    while(counter_vel <= (6-velocidad)){
        PORTCbits.RC1 = 1;
        __delay_us(284);
        PORTCbits.RC1 = 0;
        __delay_us(284);
    }
    TMR1Flag = 0;
    //TMR0_StopTimer();
    counter_vel = 0;
}
void b4_si(){
    //TMR0_StartTimer();
    while(counter_vel <= (6-velocidad)){
        PORTCbits.RC1 = 1;
        __delay_us(253);
        PORTCbits.RC1 = 0;
        __delay_us(253);
    }
    TMR1Flag = 0;
    //TMR0_StopTimer();
    counter_vel = 0;
}
unsigned char stoplargo(){
    __delay_ms(50);
    if(PORTBbits.RB0 ==  0)
        return 1; 
    return 0;
}
void stopcorto(){
    __delay_ms(5);   
}
void Martinillo(){
    c4_do();
    stopcorto();
    d4_re();
    stopcorto();
    e4_mi();
    stopcorto();
    c4_do();
    stopcorto();
    c4_do();
    stopcorto();
    d4_re();
    stopcorto();
    e4_mi();
    stopcorto();
    c4_do();
    stopcorto();

    if(stoplargo()==1)return;
    
    e4_mi();
    stopcorto();
    g4_sol();
    stopcorto();
    c4_do();
    stopcorto();
    e4_mi();
    stopcorto();
    g4_sol();
    stopcorto();
    c4_do();
    stopcorto();

    if(stoplargo()==1)return;

    g4_sol();
    stopcorto();
    a4_la();
    stopcorto();
    g4_sol();
    stopcorto();
    f4_fa();
    stopcorto();
    e4_mi();
    stopcorto();
    c4_do();
    stopcorto();
    g4_sol();
    stopcorto();
    a4_la();
    stopcorto();
    g4_sol();
    stopcorto();
    f4_fa();
    stopcorto();
    e4_mi();
    stopcorto();
    c4_do();
    stopcorto();

    if(stoplargo()==1)return;

    d4_re();
    stopcorto();
    g4_sol();
    stopcorto();
    c4_do();
    stopcorto();
    d4_re();
    stopcorto();
    g4_sol();
    stopcorto();
    c4_do();
    stopcorto();

    if(stoplargo()==1)return;
}
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    
    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    
    TMR0_WriteTimer(53816);
    //TMR0_WriteTimer(18660); //prescaler 110 1SEC
    counter = 0;
    while (1)
    {
        if (PORTBbits.RB0 == 1){
            TMR0_StartTimer();
            Martinillo();
        }
        else{
            TMR0_StopTimer();
            counter=0;
            counter2=0;
            velocidad=1;
        }        
    }
}

