#include "tmr0.h"
#include "mcc.h"

/**
  Section: Global Variables Definitions
*/
volatile uint8_t timer0ReloadVal8bit;

volatile uint16_t timer0ReloadVal;

/**
  Section: TMR0 APIs
*/


void TMR0_Initialize(void)
{
    // T0PS 1:256; T08BIT 8-bit; T0SE Increment_hi_lo; T0CS FOSC/4; TMR0ON enabled; PSA assigned; 
    T0CON = 0b00000101;

    //TMR0_Write8bitTimer(246);

    // Clear Interrupt flag before enabling the interrupt
    INTCONbits.TMR0IF = 0;

    // Enabling TMR0 interrupt.
    INTCONbits.TMR0IE = 1;

    // Start TMR0
    TMR0_StartTimer();
}

void TMR0_StartTimer(void)
{
    // Start the Timer by writing to TMR0ON bit
    T0CONbits.TMR0ON = 1;
}

void TMR0_StopTimer(void)
{
    // Stop the Timer by writing to TMR0ON bit
    T0CONbits.TMR0ON = 0;
}


uint8_t TMR0_Read8bitTimer(void)
{
    uint8_t readVal;

    // read Timer0, low register only
    readVal = TMR0L;

    return readVal;
}

void TMR0_Write8bitTimer(uint8_t timerVal)
{
    // Write to the Timer0 registers, low register only
    TMR0L = timerVal;
 }

void TMR0_Reload8bit(void)
{
    //Write to the Timer0 register
    TMR0L = timer0ReloadVal8bit;
}

uint16_t TMR0_ReadTimer(void)
{
    uint16_t readVal;
    uint8_t readValHigh;
    uint8_t readValLow;
    
    readValLow = TMR0L;
    readValHigh = TMR0H;
    
    readVal = ((uint16_t)readValHigh << 8) | readValLow;

    return readVal;
}

void TMR0_WriteTimer(uint16_t timerVal)
{
    // Write to the Timer0 registers
    TMR0H = (timerVal >> 8);
    TMR0L = (uint8_t) timerVal;
    
}

void TMR0_Reload(void)
{
    // Write to the Timer1 register
    TMR0H = (timer0ReloadVal >> 8);
    TMR0L = (uint8_t) timer0ReloadVal;
}



void TMR0_ISR(void)
{
    // add your TMR0 interrupt custom code
    TMR1Flag=1;
    counter_vel++;
    if(counter == 1)
        velocidad = 1;
    if(counter == 15)
        velocidad = 2;
    if(counter == 30)
        velocidad = 3;
    if(counter == 45)
        velocidad = 4;
    if(counter == 60)
        velocidad = 5;
    if(counter == 75)
        velocidad = 6;
    if(counter == 90)
        velocidad = 7;
    counter2++;
    if(counter2 == 8){
        counter++;
        counter2 = 0;
    } 
    TMR0_WriteTimer(53816);
}

/**
  End of File
*/