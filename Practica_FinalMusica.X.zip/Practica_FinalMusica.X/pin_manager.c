
#include "pin_manager.h"
#include "mcc.h"

void PIN_MANAGER_Initialize(void)
{
    //configure ports below this line
    TRISBbits.TRISB0 = 1;
    TRISBbits.TRISB7 = 0;
    TRISCbits.TRISC1 = 0;
    //PORTA, PORTB and PORTE are digital
    ADCON1bits.PCFG = 0xF; 
    
}

void PIN_MANAGER_IOC(void)
{
    
    
}

void PIN_MANAGER_INT0(void)
{
    
}

void PIN_MANAGER_INT1(void)
{

}

void PIN_MANAGER_INT2(void)
{

}