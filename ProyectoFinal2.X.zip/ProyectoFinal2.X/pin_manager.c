
#include "pin_manager.h"
#include "mcc.h"

void PIN_MANAGER_Initialize(void)
{
    //configure ports below this line
    TRISBbits.TRISB1 = 0; //RA/0AN0 is an input
    TRISAbits.TRISA0 = 1; //RA/0AN0 is an input
    //PORTA, PORTB and PORTE are digital
    ADCON1bits.PCFG = 0xE; 
}

void PIN_MANAGER_IOC(void)
{
    
}

void PIN_MANAGER_INT0(void)
{
    
}

void PIN_MANAGER_INT1(void)
{
    
}

void PIN_MANAGER_INT2(void)
{
    
}