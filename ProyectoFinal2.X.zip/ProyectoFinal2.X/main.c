#include "mcc.h"
#include "stdio.h"
#include "stdlib.h"
#include <xlcd.h>

//char array4[3][80]={{32,60,32,32,32,32,60,32,32,32,32,60,60,32,60,32,60,32,60,32,32,60,32,32,32,60,32,32,60,32,32,32,32,32,32,32,60,32,60,32,60,32,32,32,32,32,32,32,32,60,32,32,32,60,32,32,32,32,32,32,32,60,32,32,32,60,32,60,32,32,32,32,32,32,32,60,60,60,60,60},{32,32,32,60,32,32,32,32,32,60,32,32,60,32,32,32,32,60,32,60,32,32,32,60,32,32,60,32,32,60,32,32,60,60,32,32,32,60,32,60,32,32,32,32,60,60,32,32,32,32,60,32,32,32,32,32,32,60,32,32,32,32,32,60,32,32,60,32,32,32,60,32,60,32,32,32,32,32,32,32},{32,60,32,32,60,32,32,60,32,60,32,32,32,32,60,32,32,32,32,32,32,60,32,32,32,32,32,32,32,32,32,60,32,32,32,32,32,32,32,32,32,32,32,60,32,32,60,32,32,32,32,32,32,32,60,32,60,32,32,32,32,32,32,32,32,32,32,32,32,32,32,60,32,60,32,60,60,60,60,60}};
char array4[3][100]={{' ','<',' ',' ',' ',' ','<',' ',' ',' ',' ','<','<',' ','<',' ','<',' ','<',' ',' ','<',' ',' ',' ','<',' ',' ','<',' ',' ',' ',' ',' ',' ',' ','<',' ','<',' ','<',' ',' ',' ',' ',' ',' ',' ',' ','<',' ',' ',' ','<',' ',' ',' ',' ',' ',' ',' ','<',' ',' ',' ','<',' ','<',' ',' ',' ',' ',' ',' ',' ','<','<','<','<','<',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},{' ',' ',' ','<',' ',' ',' ',' ',' ','<',' ',' ','<',' ',' ',' ',' ','<',' ','<',' ',' ',' ','<',' ',' ','<',' ',' ','<',' ',' ','<','<',' ',' ',' ','<',' ','<',' ',' ',' ',' ','<','<',' ',' ',' ',' ','<',' ',' ',' ',' ',' ',' ','<',' ',' ',' ',' ',' ','<',' ',' ','<',' ',' ',' ','<',' ','<',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},{' ','<',' ',' ','<',' ',' ','<',' ','<',' ',' ',' ',' ','<',' ',' ',' ',' ',' ',' ','<',' ',' ',' ',' ',' ',' ',' ',' ',' ','<',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<',' ',' ','<',' ',' ',' ',' ',' ',' ',' ','<',' ','<',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<',' ','<',' ','<','<','<','<','<',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '}};

void Setup(){
    //char array4[3][80]={{32,60,32,32,32,32,60,32,32,32,32,60,60,32,60,32,60,32,60,32,32,60,32,32,32,60,32,32,60,32,32,32,32,32,32,32,60,32,60,32,60,32,32,32,32,32,32,32,32,60,32,32,32,60,32,32,32,32,32,32,32,60,32,32,32,60,32,60,32,32,32,32,32,32,32,60,60,60,60,60},{32,32,32,60,32,32,32,32,32,60,32,32,60,32,32,32,32,60,32,60,32,32,32,60,32,32,60,32,32,60,32,32,60,60,32,32,32,60,32,60,32,32,32,32,60,60,32,32,32,32,60,32,32,32,32,32,32,60,32,32,32,32,32,60,32,32,60,32,32,32,60,32,60,32,32,32,32,32,32,32},{32,60,32,32,60,32,32,60,32,60,32,32,32,32,60,32,32,32,32,32,32,60,32,32,32,32,32,32,32,32,32,60,32,32,32,32,32,32,32,32,32,32,32,60,32,32,60,32,32,32,32,32,32,32,60,32,60,32,32,32,32,32,32,32,32,32,32,32,32,32,32,60,32,60,32,60,60,60,60,60}};
    //array1 = array4;
    //array1[] = {32,60,32,32,32,32,60,32,32,32,32,60,60,32,60,32,60,32,60,32,32,60,32,32,32,60,32,32,60,32,32,32,32,32,32,32,60,32,60,32,60,32,32,32,32,32,32,32,32,60,32,32,32,60,32,32,32,32,32,32,32,60,32,32,32,60,32,60,32,32,32,32,32,32,32,60,60,60,60,60};
    //array2[] = {32,32,32,60,32,32,32,32,32,60,32,32,60,32,32,32,32,60,32,60,32,32,32,60,32,32,60,32,32,60,32,32,60,60,32,32,32,60,32,60,32,32,32,32,60,60,32,32,32,32,60,32,32,32,32,32,32,60,32,32,32,32,32,60,32,32,60,32,32,32,60,32,60,32,32,32,32,32,32,32};
    //array3[] = {32,60,32,32,60,32,32,60,32,60,32,32,32,32,60,32,32,32,32,32,32,60,32,32,32,32,32,32,32,32,32,60,32,32,32,32,32,32,32,32,32,32,32,60,32,32,60,32,32,32,32,32,32,32,60,32,60,32,32,32,32,32,32,32,32,32,32,32,32,32,32,60,32,60,32,60,60,60,60,60};
    velocidad = 1;
    while(BusyXLCD());
    WriteCmdXLCD(0b00000001);
    while(BusyXLCD());
    SetDDRamAddr(0x0);
    while(BusyXLCD());
    putrsXLCD("LOADING.");
    __delay_ms(500);
    while(BusyXLCD());
    SetDDRamAddr(0x0);
    while(BusyXLCD());
    putrsXLCD("LOADING..");
    __delay_ms(500);
    while(BusyXLCD());
    SetDDRamAddr(0x0);
    while(BusyXLCD());
    putrsXLCD("LOADING...");
    __delay_ms(500);    
    
    while(BusyXLCD());
    WriteCmdXLCD(0b00000001);
    while(BusyXLCD());
    SetDDRamAddr(0x0);
    while(BusyXLCD());
    putrsXLCD("STARTING IN 3");
    __delay_ms(1000);
    SetDDRamAddr(0x0);
    while(BusyXLCD());
    putrsXLCD("STARTING IN 2");
    __delay_ms(1000);
    while(BusyXLCD());
    SetDDRamAddr(0x0);
    while(BusyXLCD());
    putrsXLCD("STARTING IN 1");
    PORTBbits.RB1 = 1; //Habilita m�sica 
    TMR0_StartTimer();
}
void recorrerArray(){
    for (int i = 0; i<20; i++){
        if ((position + i) < 80){
            pantalla[0][position + i] = array4[0][position + i];
            pantalla[1][position + i] = array4[1][position + i];
            pantalla[2][position + i] = array4[2][position + i];
        }else{
            pantalla[0][position + i] = ' ';
            pantalla[1][position + i] = ' ';
            pantalla[2][position + i] = ' ';
        }       
    }
    position++;
}
void printDisplay(){
    ADC_ISR();
    for (int i = 0; i<20; i++){
        pantalla[0][position + i] = array4[0][position + i];
        pantalla[1][position + i] = array4[1][position + i];
        pantalla[2][position + i] = array4[2][position + i];    
    }
    if (array4[lane -1][position] == '<'){
        puntaje = puntaje - velocidad*2;
    }
    //pantalla[lane -1][0] = '>';
    while(BusyXLCD());
    WriteCmdXLCD(0b00000001);
    
    while(BusyXLCD());
    SetDDRamAddr(0x80);
    for (int i = 0; i<20; i++){
        while(BusyXLCD());                                      //Zumba acidin
        WriteDataXLCD(pantalla[0][position+i]);                 //Zumba pica
    }
    while(BusyXLCD());
    
    while(BusyXLCD());
    SetDDRamAddr(0xC0);
    for (int i = 0; i<20; i++){
        while(BusyXLCD());                                      //Zumba acidin
        WriteDataXLCD(pantalla[1][position+i]);                 //Zumba pica
    }
    while(BusyXLCD());
    
    SetDDRamAddr(0x94);
    while(BusyXLCD());
    for (int i = 0; i<20; i++){
        while(BusyXLCD());                                      //Zumba acidin
        WriteDataXLCD(pantalla[2][position+i]);                 //Zumba pica
    }
    while(BusyXLCD());
    
    while(BusyXLCD());
    SetDDRamAddr(0xD4);
    //sprintf(points, "C: %d", counter);
    sprintf(points, "Score: %d Speed: %d", puntaje, velocidad);
    //sprintf(points, "A:%d L:%d C:%d", value, lane,counter);
    while(BusyXLCD());
    putsXLCD(points);
    if(lane == 1){
        while(BusyXLCD());
        SetDDRamAddr(0x80);
        while(BusyXLCD());                                      //Zumba acidin
        WriteDataXLCD('>');                 //Zumba pica
        while(BusyXLCD());
        SetDDRamAddr(0xE7);
    }
    else if(lane == 2){
        while(BusyXLCD());
        SetDDRamAddr(0xC0);
        while(BusyXLCD());                                      //Zumba acidin
        WriteDataXLCD('>');                 //Zumba pica
        while(BusyXLCD());
        SetDDRamAddr(0xE7);
    }
    else if(lane == 3){
        while(BusyXLCD());
        SetDDRamAddr(0x94);
        while(BusyXLCD());                                      //Zumba acidin
        WriteDataXLCD('>');                 //Zumba pica
        while(BusyXLCD());
        SetDDRamAddr(0xE7);
    }
}
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    
    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    TMR0_WriteTimer(18660);
    PORTBbits.RB1 = 0;
    TMR0_StopTimer();
    puntaje = 0;
    position = 0;
    velocidad = 1;
    counter = 0;
    lane = 1;
    Setup();
    ADC_StartConversion(0);
    while (1)
    {
       if(Timer_Flag == 1){
           Timer_Flag = 0;
           if(counter == 6){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 12){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 18){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 24){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 30){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter < 30){
               if(counter % 2 == 0){
                    puntaje = puntaje + velocidad;
               }
               printDisplay();
           }
           else if(counter == 35){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 40){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 45){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 50){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 55){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 60){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter < 60){
               if(counter % 2 == 0){
                    puntaje = puntaje + velocidad;
               }
               printDisplay();
           }
           else if(counter == 64){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 68){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 72){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 76){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 80){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 84){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 88){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter < 88){
               if(counter % 2 == 0){
                    puntaje = puntaje + velocidad;
               }
               printDisplay();
           }
           else if(counter == 91){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 94){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 97){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 100){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 103){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 106){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 109){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 112){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 115){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 118){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter < 118){
               if(counter % 2 == 0){
                    puntaje = puntaje + velocidad;
               }
               printDisplay();
           }
           else if(counter == 120){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 122){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 124){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 126){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 128){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 130){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 132){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 134){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 136){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 138){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
            else if(counter == 140){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 142){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 144){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 146){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 148){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 150){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter < 150){
               if(counter % 2 == 0){
                    puntaje = puntaje + velocidad;
               }
               printDisplay();
           }
           else if(counter == 151){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 152){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 153){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 154){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 155){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 156){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 157){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 158){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 159){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 160){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
            else if(counter == 161){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 162){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 163){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 164){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 165){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 166){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 167){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 168){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 169){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 170){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 171){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 172){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 173){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 174){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 175){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 176){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 177){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 178){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 179){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter == 180){
               recorrerArray();
               puntaje = puntaje + velocidad;
               printDisplay();
           }
           else if(counter < 180){
               if(counter % 2 == 0){
                    puntaje = puntaje + velocidad;
               }
               printDisplay();
           }
           else {
               while(BusyXLCD());
               WriteCmdXLCD(0b00000001);
               while(BusyXLCD());
               SetDDRamAddr(0x00);
               while(BusyXLCD());
               putrsXLCD("GAME OVER");
               while(BusyXLCD());
               SetDDRamAddr(0x40);
               sprintf(points, "Score: %d", puntaje);
               while(BusyXLCD());
               putsXLCD(points);
               PORTBbits.RB1 = 0;
               TMR0_StopTimer();
               puntaje = 0;
               position = 0;
               velocidad = 1;
               counter = 0;
           }
       }
    }
}